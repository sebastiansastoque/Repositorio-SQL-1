-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-04-2024 a las 02:34:56
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `libreria_1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `cod_cliente` int(11) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(25) NOT NULL,
  `ciudad` varchar(25) NOT NULL,
  `fecha_ingreso` date DEFAULT curdate(),
  `cod_vendedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`cod_cliente`, `nombre`, `apellido`, `direccion`, `telefono`, `ciudad`, `fecha_ingreso`, `cod_vendedor`) VALUES
(1, 'Oscar', 'Doe', 'calle 45-2', '123490', 'Bogotá', '2024-04-08', 0),
(2, 'Jane', 'Doe', 'carrera 45', '234561', 'Los Bogotá', '2024-04-08', 0),
(3, 'Bob', 'Smith', 'Av. 32-10', '3456012', 'Cali', '2024-04-08', 0),
(4, 'Mary', 'Johnson', 'Av 80-52 sur', '456783', 'Bogotá', '2024-04-08', 0),
(5, 'Ana', 'Perez', 'Calle 123', '123456', 'Bogotá', '2024-04-08', 0),
(6, 'Juan', 'Rodriguez', 'Calle 456', '234567', 'Medellín', '2024-04-08', 0),
(7, 'Maria', 'Lopez', 'Calle 789', '345678', 'Cali', '2024-04-08', 0),
(8, 'Carlos', 'Gonzalez', 'Calle 101', '456789', 'Bogotá', '2024-04-08', 0),
(9, 'Maria', 'Perez', 'Carrera 3', '123456', 'Bogotá', '2024-04-08', 0),
(10, 'Juan', 'Lopez', 'Calle 456', '234567', 'Medellín', '2024-04-08', 0),
(11, 'Ana', 'Rodriguez', 'Calle 789', '345678', 'Cali', '2024-04-08', 0),
(12, 'Carlos', 'Perez', 'Calle 101', '456789', 'Bogotá', '2024-04-08', 0),
(13, 'Maria', 'Lopez', 'Calle 123', '123456', 'Bogotá', '2024-04-08', 0),
(14, 'Juan', 'Rodriguez', 'Calle 456', '234567', 'Medellín', '2024-04-08', 0),
(15, 'Jennifer', 'Hernandez', 'Carrera 8 #45-56 sur', '452986', 'Madellín', '2024-04-08', 0),
(16, 'David', 'Martinez', 'carrera 56 #161-71', '225698', 'Barranquilla', '2024-04-08', 0),
(17, 'Daniel', 'Walker', 'Cra 93 #96-45', '654823', 'Cali', '2024-04-08', 0),
(18, 'Jose', 'Thompson', 'Carrera 7 norte', '589412', 'Medellín', '2024-04-08', 0),
(19, 'Robert', 'Anderson', 'Av Calle 53', '695695', 'Bogotá', '2024-04-08', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ventas`
--

CREATE TABLE `detalle_ventas` (
  `num_factura` int(11) NOT NULL,
  `cod_libro` int(11) NOT NULL,
  `precio_venta` decimal(10,2) DEFAULT 0.00,
  `cantidad` int(11) NOT NULL,
  `total_linea` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_ventas`
--

INSERT INTO `detalle_ventas` (`num_factura`, `cod_libro`, `precio_venta`, `cantidad`, `total_linea`) VALUES
(1, 101, 25.50, 2, 51.00),
(1, 102, 30.00, 1, 30.00),
(2, 103, 20.00, 3, 60.00),
(2, 104, 15.75, 2, 31.50),
(3, 105, 18.20, 5, 91.00),
(3, 106, 22.50, 2, 45.00),
(4, 107, 35.75, 1, 35.75),
(4, 108, 40.00, 3, 120.00),
(5, 109, 28.50, 2, 57.00),
(5, 110, 19.75, 4, 79.00),
(6, 111, 32.00, 1, 32.00),
(6, 112, 27.50, 2, 55.00),
(7, 113, 23.75, 3, 71.25),
(7, 114, 17.00, 1, 17.00),
(8, 115, 29.25, 2, 58.50),
(8, 116, 24.00, 1, 24.00),
(9, 117, 16.50, 4, 66.00),
(9, 118, 21.80, 2, 43.60),
(10, 119, 18.75, 1, 18.75),
(10, 120, 26.00, 3, 78.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `editorial`
--

CREATE TABLE `editorial` (
  `cod_editorial` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `NIT` int(11) DEFAULT NULL,
  `direccion` varchar(50) NOT NULL,
  `ciudad` varchar(25) NOT NULL,
  `telefono` varchar(25) NOT NULL,
  `contacto` varchar(25) NOT NULL,
  `pagina_web` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `editorial`
--

INSERT INTO `editorial` (`cod_editorial`, `nombre`, `NIT`, `direccion`, `ciudad`, `telefono`, `contacto`, `pagina_web`) VALUES
(1, 'Editorial Planeta', 123456, 'Carrera 12 # 34-56', 'Bogotá', '1234567', 'Juan González', 'www.editorialplaneta.com'),
(2, 'Editorial Planeta', 987654321, 'Calle 123', 'Bogotá', '123456', 'Ana Rodriguez', 'www.editorialplaneta.com'),
(3, 'Editorial Planeta', 123456789, 'Calle 123', 'Bogotá', '123456789', 'Juan Pérez', 'www.editorialplaneta.com'),
(4, 'Editorial Santillana', 987654321, 'Calle 456', 'Medellín', '987654321', 'María López', 'www.editorialsantillana.c'),
(5, 'Editorial Norma', 111222333, 'Calle 789', 'Cali', '111222333', 'Carlos Rodríguez', 'www.editorialnorma.com'),
(6, 'Editorial Random House', 222333444, 'Calle 101', 'Barranquilla', '222333444', 'Ana Gómez', 'www.editorialrandomhouse.'),
(7, 'Editorial Penguin Random House', 333444555, 'Calle 102', 'Bogotá', '333444555', 'Pedro Martínez', 'www.editorialpenguinrando'),
(8, 'Editorial Random House', 222333444, 'Calle 103', 'Bogotá', '222333444', 'Laura Sánchez', 'www.editorialrandomhouse.'),
(9, 'Editorial Santillana', 987654321, 'Calle 457', 'Medellín', '987654321', 'Juan Pérez', 'www.editorialsantillana.c'),
(10, 'Editorial Planeta', 123456789, 'Calle 124', 'Bogotá', '123456789', 'María López', 'www.editorialplaneta.com'),
(11, 'Editorial Norma', 111222333, 'Calle 790', 'Cali', '111222333', 'Carlos Rodríguez', 'www.editorialnorma.com'),
(12, 'Editorial Random House', 222333444, 'Calle 104', 'Barranquilla', '222333444', 'Ana Gómez', 'www.editorialrandomhouse.'),
(13, 'Editorial Penguin Random House', 333444555, 'Calle 105', 'Bogotá', '333444555', 'Pedro Martínez', 'www.editorialpenguinrando'),
(14, 'Editorial Random House', 222333444, 'Calle 106', 'Bogotá', '222333444', 'Laura Sánchez', 'www.editorialrandomhouse.'),
(15, 'Editorial Santillana', 987654321, 'Calle 458', 'Medellín', '987654321', 'Juan Pérez', 'www.editorialsantillana.c'),
(16, 'Editorial Planeta', 123456789, 'Calle 125', 'Bogotá', '123456789', 'María López', 'www.editorialplaneta.com'),
(17, 'Editorial Norma', 111222333, 'Calle 791', 'Cali', '111222333', 'Carlos Rodríguez', 'www.editorialnorma.com'),
(18, 'Editorial alianza', 234567890, 'Calle 26 #45-8', 'Medellín', '234567890', 'María García', 'www.editorialalianza.com'),
(19, 'Editorial Alianza', 345678901, 'Calle 3 av 8', 'Cali', '345678901', 'Pedro López', 'www.editorialalianza.com'),
(20, 'Editorial D', 456789012, 'Calle 45', 'Bogotá', '456789012', 'Ana Rodríguez', 'www.editorialD.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `cod_libro` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `cod_editorial` int(11) NOT NULL,
  `precio_compra` decimal(10,2) DEFAULT 0.00,
  `existencia` int(11) NOT NULL,
  `disponible` int(11) NOT NULL,
  `cod_tema` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`cod_libro`, `titulo`, `cod_editorial`, `precio_compra`, `existencia`, `disponible`, `cod_tema`) VALUES
(1, 'El señor de los anillos', 1, 10.00, 100, 100, 1),
(2, 'Harry Potter y la piedra filosofal', 2, 15.00, 50, 50, 2),
(3, 'Juego de tronos', 3, 20.00, 25, 25, 3),
(4, 'La casa de los espíritus', 1, 12.00, 75, 75, 1),
(5, 'El código da Vinci', 2, 8.00, 150, 150, 2),
(6, 'Lolita', 3, 18.00, 30, 30, 3),
(7, 'Cien años de soledad', 1, 25.00, 20, 20, 1),
(8, 'Un mundo feliz', 2, 12.50, 100, 100, 2),
(9, 'Lolita', 3, 24.00, 20, 20, 3),
(10, 'En busca del tiempo perdido', 1, 23.00, 30, 30, 1),
(11, 'Un mundo feliz', 2, 13.00, 250, 250, 2),
(12, 'En busca del tiempo perdido', 3, 28.00, 15, 15, 3),
(13, 'Cien años de soledad', 1, 21.00, 45, 45, 1),
(14, 'Don Quijote de la Mancha', 2, 9.50, 200, 200, 2),
(15, 'El retrato de Dorian Gray', 3, 30.00, 5, 5, 3),
(16, 'La Odisea', 1, 14.00, 60, 60, 1),
(17, 'Cumbres borrascosas', 2, 10.50, 180, 180, 2),
(18, 'Cien años de soledad', 3, 24.00, 20, 20, 3),
(19, 'Frankenstein', 1, 23.00, 30, 30, 1),
(20, 'Alicia en el país de las maravillas', 2, 13.00, 250, 250, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `temas`
--

CREATE TABLE `temas` (
  `cod_tema` int(11) NOT NULL,
  `nombre_tema` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `temas`
--

INSERT INTO `temas` (`cod_tema`, `nombre_tema`) VALUES
(1, 'Ficción'),
(2, 'Infantil'),
(3, 'Cocina'),
(4, 'Historia'),
(5, 'No Ficción'),
(6, 'Novela'),
(7, 'Poesía'),
(8, 'Historia'),
(9, 'Ciencia Ficción'),
(10, 'Drama'),
(11, 'Novela'),
(12, 'Poesía'),
(13, 'Historia'),
(14, 'Ciencia Ficción'),
(15, 'Drama'),
(16, 'Infantil'),
(17, 'Cocina'),
(18, 'Historia'),
(19, 'Biografía'),
(20, 'Ficción');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedores`
--

CREATE TABLE `vendedores` (
  `cod_vendedor` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `ciudad` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vendedores`
--

INSERT INTO `vendedores` (`cod_vendedor`, `nombre`, `apellido`, `direccion`, `telefono`, `ciudad`) VALUES
(1, 'Juan', 'Perez', 'Cl 90 No. 12-45', '123456789', 'Bogota'),
(2, 'Maria', 'Gomez', ' Cl 33 No. 65-47', '234567890', 'Medellin'),
(3, 'Pedro', 'Lopez', 'Cl 5 A No. 39-18', '345678901', 'Cali'),
(4, 'Ana', 'Rodriguez', 'Calle 4', '456789012', 'Bogota'),
(5, 'Carlos', 'Gomez', ' Cr.18 No.25D-33', '567890123', 'Cartagena'),
(6, 'Laura', 'Gonzalez', 'Calle 6', '678901234', 'Barranquilla'),
(7, 'Jose', 'Ramirez', 'Cl 45 No. 51-51', '789012345', 'Bucaramanga'),
(8, 'Sara', 'Hernandez', 'Cl 20 N No. 8 N-22', '890123456', 'Cucuta'),
(9, 'Andres', 'Martinez', 'Cr 9 No. 113-90 ', '901234567', 'Pasto'),
(10, 'Luisa', 'Fernandez', 'Calle 10', '012345678', 'Manizales'),
(11, 'Daniel', 'Perez', 'Cr 15 No. 13-45', '1234567890', 'Tunja'),
(12, 'Maria', 'Garcia', 'Cr 49 B No. 79-71', '2345678901', 'Villavicencio'),
(13, 'Juan', 'Gomez', 'Calle 13', '3456789012', 'Ibague'),
(14, 'Pedro', 'Lopez', 'Cr 70A No. 43-22', '4567890123', 'Popayan'),
(15, 'Ana', 'Rodriguez', ' Cr 55 No. 51-91 ', '5678901234', 'Sincelejo'),
(16, 'Carlos', 'Gomez', 'Calle 16', '6789012345', 'Santa Marta'),
(17, 'Laura', 'Gonzalez', 'Cr 46 No. 85-52', '7890123456', 'Monteria'),
(18, 'Jose', 'Ramirez', 'Cl 59A No. 8-43', '8901234567', 'Valledupar'),
(19, 'Sara', 'Hernandez', 'Calle 19', '9012345678', 'Barrancabermeja'),
(20, 'Andres', 'Martinez', 'Calle 45', '01234567890', 'Neiva');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `num_factura` int(11) NOT NULL,
  `fecha_ventas` date DEFAULT curdate(),
  `cod_cliente` int(11) DEFAULT NULL,
  `pagado` varchar(50) NOT NULL,
  `forma_pago` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`num_factura`, `fecha_ventas`, `cod_cliente`, `pagado`, `forma_pago`) VALUES
(1, '2024-04-09', 1, 'pagado', 'Efectivo'),
(2, '2024-04-09', 2, 'no pagado', 'Transferencia bancaria'),
(3, '2024-04-09', 2, 'pagado', 'Transferencia bancaria'),
(4, '2024-04-09', 1, 'pagado', 'Efectivo'),
(5, '2024-04-09', 3, 'no pagado', 'Tarjeta de débito'),
(6, '2024-04-09', 1, 'no pagado', 'Tarjeta de crédito'),
(7, '2024-04-09', 2, 'pagado', 'Efectivo'),
(8, '2024-04-09', 3, 'no pagado', 'Transferencia bancaria'),
(9, '2024-04-09', 4, 'pagado', 'PayPal'),
(10, '2024-04-09', 5, 'no pagado', 'Tarjeta de débito'),
(11, '2024-04-09', 1, 'pagado', 'Efectivo'),
(12, '2024-04-09', 2, 'pagado', 'Tarjeta de crédito'),
(13, '2024-04-09', 3, 'no pagado', 'Efectivo'),
(14, '2024-04-09', 4, 'no pagado', 'Tarjeta de débito'),
(15, '2024-04-09', 1, 'pagado', 'Tarjeta de crédito'),
(16, '2024-04-09', 2, 'pagado', 'Efectivo'),
(17, '2024-04-09', 3, 'no pagado', 'Transferencia bancaria'),
(18, '2024-04-09', 4, 'pagado', 'PayPal'),
(19, '2024-04-09', 5, 'pagado', 'Tarjeta de débito'),
(20, '2024-04-09', 5, 'no pagado', 'PayPal');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cod_cliente`),
  ADD KEY `nombre` (`nombre`,`apellido`);

--
-- Indices de la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD PRIMARY KEY (`num_factura`,`cod_libro`),
  ADD KEY `cod_libro` (`cod_libro`);

--
-- Indices de la tabla `editorial`
--
ALTER TABLE `editorial`
  ADD PRIMARY KEY (`cod_editorial`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`cod_libro`),
  ADD KEY `cod_editorial` (`cod_editorial`),
  ADD KEY `cod_tema` (`cod_tema`);

--
-- Indices de la tabla `temas`
--
ALTER TABLE `temas`
  ADD PRIMARY KEY (`cod_tema`);

--
-- Indices de la tabla `vendedores`
--
ALTER TABLE `vendedores`
  ADD PRIMARY KEY (`cod_vendedor`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`num_factura`),
  ADD KEY `cod_cliente` (`cod_cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `cod_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `editorial`
--
ALTER TABLE `editorial`
  MODIFY `cod_editorial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `cod_libro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `temas`
--
ALTER TABLE `temas`
  MODIFY `cod_tema` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `vendedores`
--
ALTER TABLE `vendedores`
  MODIFY `cod_vendedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `num_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD CONSTRAINT `detalle_ventas_ibfk_1` FOREIGN KEY (`num_factura`) REFERENCES `ventas` (`num_factura`),
  ADD CONSTRAINT `detalle_ventas_ibfk_2` FOREIGN KEY (`cod_libro`) REFERENCES `libros` (`cod_libro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `ventas_ibfk_1` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`cod_cliente`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
